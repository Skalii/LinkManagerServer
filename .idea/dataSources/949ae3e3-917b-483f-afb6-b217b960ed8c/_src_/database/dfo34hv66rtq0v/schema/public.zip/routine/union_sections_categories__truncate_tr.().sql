create function union_sections_categories__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE sections
  SET ids_category = ARRAY[]::INTEGER[];

  RETURN NULL;
END;
$$;
