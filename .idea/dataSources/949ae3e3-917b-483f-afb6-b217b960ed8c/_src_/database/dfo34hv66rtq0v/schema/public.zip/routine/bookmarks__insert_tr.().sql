create function bookmarks__insert_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.profiles
  SET ids_bookmark = ids_bookmark + NEW.id_site
  WHERE id_profile = NEW.id_profile;

  RETURN NEW;
END;
$$;
