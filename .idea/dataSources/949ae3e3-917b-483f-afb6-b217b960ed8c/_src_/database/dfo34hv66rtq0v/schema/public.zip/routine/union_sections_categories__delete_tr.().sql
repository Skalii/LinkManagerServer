create function union_sections_categories__delete_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE sections
  SET ids_category = ids_category - OLD.id_category
  WHERE id_section = OLD.id_section;

  RETURN OLD;
END;
$$;
